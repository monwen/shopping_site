import React from 'react';

const Clock = props => {
    return <h1>The time is {props.time}</h1>
}

export default Clock;