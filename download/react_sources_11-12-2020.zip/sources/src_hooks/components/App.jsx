import React from 'react';
import StateCounter from './StateCounter';

const App = () => {

    return (
        <div>
            <StateCounter />
        </div>
    )
};

export default App;