import React from 'react';

const Instruction = () => {
    return (
        <p>Click the Logout button to log out!</p>
    );
};

export default Instruction;