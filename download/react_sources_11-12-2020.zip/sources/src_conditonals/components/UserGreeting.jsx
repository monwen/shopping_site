import React from 'react';

const UserGreting = props => {
    return (
        <div>
            Welcome {props.user}
        </div>
    );
};

export default UserGreting;