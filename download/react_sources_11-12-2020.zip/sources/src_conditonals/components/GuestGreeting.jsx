import React from 'react';

const GuestGreeting = () => {
    return (
        <div>
            Welcome Guest!
        </div>
    );
};

export default GuestGreeting;